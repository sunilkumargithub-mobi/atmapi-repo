package com.mobiquity.atmapi.delegate;

import java.util.List;

import com.mobiquity.atmapi.vo.ATMS;

public interface IDelegateManager {
	public String getALLATMList();
	public List<ATMS> getATMListByCity(String city);

}
