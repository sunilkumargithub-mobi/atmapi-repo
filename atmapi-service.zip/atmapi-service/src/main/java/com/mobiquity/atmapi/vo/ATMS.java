package com.mobiquity.atmapi.vo;

import java.util.Arrays;

public class ATMS {
	
	private Address address;
	private Integer distance;
	private OpeningHours[] openingHours;
	private String functionality;
	private String type;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Integer getDistance() {
		return distance;
	}
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	public OpeningHours[] getOpeningHours() {
		return openingHours;
	}
	public void setOpeningHours(OpeningHours[] openingHours) {
		this.openingHours = openingHours;
	}
	public String getFunctionality() {
		return functionality;
	}
	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "ATMS [address=" + address + ", distance=" + distance + ", openingHours=" + Arrays.toString(openingHours)
				+ ", functionality=" + functionality + ", type=" + type + "]";
	}
	
	

}
