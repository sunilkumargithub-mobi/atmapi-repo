package com.mobiquity.atmapi.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.mobiquity.atmapi.constant.ATMConstant;
import com.mobiquity.atmapi.vo.ATMErrorResponse;

/**
 * 
 * @author SunilKumar
 * 
 *  This class used to display Error response details.
 *
 */

@Component("responseUtils")
public class ResponseUtils implements ATMConstant{
	
    /**
     * 	
     * @return errResp
     * 
     *  This method used to display Service Down message  if external service down or network connection issue
     */
	public static ATMErrorResponse getServcieDownErrorResponse(){
		ATMErrorResponse errResp=new ATMErrorResponse();
		errResp.setResponseCode(ATMConstant.RESP_CODE_500);
		errResp.setResponseDescription(ATMConstant.RESP_DESCRIPTION_500);
		return errResp;
	}
	
	/**
	 * 
	 * @return errResp
	 * 
	 *  This method used to display No ATM's available message
	 */
	
	public static ATMErrorResponse getNoConfigurationResponse(){
		ATMErrorResponse errResp=new ATMErrorResponse();
		errResp.setResponseCode(ATMConstant.RESP_CODE_400);
		errResp.setResponseDescription(ATMConstant.RESP_DESCRIPTION_CITY);
		
		return errResp;
	}
	
	public HttpHeaders getHeaders(){
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Cache-control","no-cache, no-store");
		headers.add("Pragma","no-cache");
		headers.add("Expired","0");
		
		return headers;
	}

}
