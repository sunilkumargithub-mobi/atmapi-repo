package com.mobiquity.atmapi.external;

import java.net.URI;
import java.nio.charset.Charset;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.mobiquity.atmapi.exceptions.ApplicationException;
import com.mobiquity.atmapi.utils.JsonUtils;
import com.mobiquity.atmapi.utils.PropertiesUtils;
import com.mobiquity.atmapi.utils.ResponseUtils;
import com.mobiquity.atmapi.vo.ATMS;

/**
 * 
 * @author SunilKumar P
 *  This Class is used to call external Service 
 *
 */

@Component
public class ExternalServiceImpl {

	@Autowired
	PropertiesUtils propertiesUtils;

	@Autowired
	ResponseUtils responseUtils;

	@Autowired
	JsonUtils jsonUtils;
	
	/**
	 * 
	 * @return JSON response
	 * 
	 * This method used to get ALL ATM details from external service
	 */
	
	
	public String getALLATMList() {
		String response = null;

		try {
			RestTemplate restTemplate = getRestTemplate();
			String externalLink = propertiesUtils.getExternalservLink();
			HttpHeaders headers = responseUtils.getHeaders();
			HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
			response = restTemplate.exchange(new URI(externalLink), HttpMethod.GET, httpEntity, String.class).getBody();
			response = jsonUtils.formattedJsonString(response);
		} catch (Exception ex) {
			throw new ApplicationException(ex.getMessage());
		}

		return response;
	}
	
	/**
	 * 
	 * @param city
	 * @return List<ATMS>
	 * 
	 *  This method used to retrieve list of ATM details based on city
	 */

	public List<ATMS> getATMListByCity(String city) {
		String response = null;
		List<ATMS> atmsListByCIty = null;

		try {
			RestTemplate restTemplate = new RestTemplate();
			String externalLink = propertiesUtils.getExternalservLink();
			HttpHeaders headers = responseUtils.getHeaders();
			HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
			response = restTemplate.exchange(new URI(externalLink), HttpMethod.GET, httpEntity, String.class).getBody();
			response = jsonUtils.formattedJsonString(response);
			atmsListByCIty = jsonUtils.jsonConversionObject(response, city);
		} catch (Exception ex) {
			throw new ApplicationException(ex.getMessage());
		}

		return atmsListByCIty;
	}

	private RestTemplate getRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setReadTimeout(Integer.parseInt(propertiesUtils.getRead_timeout()));
		requestFactory.setConnectTimeout(Integer.parseInt(propertiesUtils.getRead_timeout()));
		restTemplate.setRequestFactory(requestFactory);
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		return restTemplate;
	}

}
