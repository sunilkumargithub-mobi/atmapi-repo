package com.mobiquity.atmapi.vo;

import org.springframework.stereotype.Component;

public class Address {
	private String street;
	private String housenumber;
	private String postalcode;
	private String city;

	private Geolocation geolocation;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHousenumber() {
		return housenumber;
	}

	public void setHousenumber(String housenumber) {
		this.housenumber = housenumber;
	}

	public String getPostalcode() {
		return postalcode;
	}

	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Geolocation getGeolocation() {
		return geolocation;
	}

	public void setGeolocation(Geolocation geolocation) {
		this.geolocation = geolocation;
	}

	@Override
	public String toString() {
		return "Address [street=" + street + ", housenumber=" + housenumber + ", postalcode=" + postalcode + ", city="
				+ city + ", geolocation=" + getGeolocation() + "]";
	}

	public static class Geolocation {

		private String lat;
		private String lng;

		public Geolocation(String lat, String lng) {
			super();
			this.lat = lat;
			this.lng = lng;

		}

		public String getLat() {
			return lat;
		}

		public String getLng() {
			return lng;
		}

		@Override
		public String toString() {
			return "Geolocation [lat=" + lat + ", lng=" + lng + "]";
		}

	}
}
