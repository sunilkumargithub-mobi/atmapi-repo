package com.mobiquity.atmapi.vo;

import java.util.List;

public class OpeningHours {
	private Integer dayOfWeek;
	private List<Hours> hours;

	public Integer getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(Integer dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public List<Hours> getHours() {
		return hours;
	}

	public void setHours(List<Hours> hours) {
		this.hours = hours;
	}

	@Override
	public String toString() {
		return "OpeningHours [dayOfWeek=" + dayOfWeek + ", hours" + getHours() + "]";
	}

	public static class Hours {
		private String hoursFrom;
		private String hoursTo;

		public Hours(String hoursFrom, String hoursTo) {
			super();
			this.hoursFrom = hoursFrom;
			this.hoursTo = hoursTo;
		}

		public String getHoursFrom() {
			return hoursFrom;
		}

		public String getHoursTo() {
			return hoursTo;
		}

		@Override
		public String toString() {
			return "Hours [hoursFrom=" + hoursFrom + ", hoursTo=" + hoursTo + "]";
		}
		
		

	}
}
