package com.mobiquity.atmapi.delegate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobiquity.atmapi.external.ExternalServiceImpl;
import com.mobiquity.atmapi.vo.ATMS;

/**
 * 
 * @author SunilKumar.P
 * 
 *  This class used as Delegate design pattern, it calls business related functionalities.
 *   ALL API calls going through this class.
 *
 */

@Service("delegateManager")
public class DelegateManagerImpl implements IDelegateManager{
	
	@Autowired
	private ExternalServiceImpl serviceImpl;
	
	@Override
	public String getALLATMList(){
		return serviceImpl.getALLATMList();
	}
	@Override
	public List<ATMS> getATMListByCity(String city){
		return serviceImpl.getATMListByCity(city);
		
	}
}
