package com.mobiquity.atmapi.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("propertiesUtils")
public class PropertiesUtils {
	
	@Value("${atm.mobiquity.external_link}")
	private String externalservLink;
	@Value("${atm.mobiquity.connect_timeout}")
	private String connect_timeout;
	@Value("${atm.mobiquity.read_timeout}")
	private String read_timeout;
	
	public String getExternalservLink() {
		return externalservLink;
	}
	public void setExternalservLink(String externalservLink) {
		this.externalservLink = externalservLink;
	}
	public String getConnect_timeout() {
		return connect_timeout;
	}
	public void setConnect_timeout(String connect_timeout) {
		this.connect_timeout = connect_timeout;
	}
	public String getRead_timeout() {
		return read_timeout;
	}
	public void setRead_timeout(String read_timeout) {
		this.read_timeout = read_timeout;
	}
	

}
