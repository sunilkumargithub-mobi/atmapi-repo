package com.mobiquity.atmapi.exceptions;

public class ApplicationException extends RuntimeException{
	
	public ApplicationException(){
		
	}
	
	public ApplicationException(String message){
		super(message);
	}
   
}
