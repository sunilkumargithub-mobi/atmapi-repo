package com.mobiquity.atmapi.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mobiquity.atmapi.delegate.IDelegateManager;
import com.mobiquity.atmapi.utils.PropertiesUtils;
import com.mobiquity.atmapi.utils.ResponseUtils;
import com.mobiquity.atmapi.vo.ATMErrorResponse;
import com.mobiquity.atmapi.vo.ATMS;


@RestController
@RequestMapping("/")
public class ATMServiceController {

	@Autowired
	private IDelegateManager delegateManager;

	@Autowired
	ResponseUtils responseUtils;

	@Autowired
	PropertiesUtils propertiesUtils;
	
	/**
	 * 
	 * @return ResponseEntity<Object>
	 * 
	 *  This API used to get a list of atms
	 */

	@GetMapping(value = "/allatmList")
	public ResponseEntity<Object> getALLATMLists() {
		Map<String, String> allAtmMap = new HashMap();
		String allatmList = null;
		try {
			// List<ATMS> allatmList=delegateManager.getALLATMList();
			allatmList = delegateManager.getALLATMList();
			HttpHeaders headers = responseUtils.getHeaders();
			// allAtmMap.put("atmList", allatmList);
			return new ResponseEntity<Object>(allatmList, headers, HttpStatus.OK);
		} catch (Exception e) {
			ATMErrorResponse errorResp = responseUtils.getServcieDownErrorResponse();
			HttpHeaders headers = responseUtils.getHeaders();
			Map<String, ATMErrorResponse> erroMap = new HashMap();
			erroMap.put("errorMap", errorResp);
			return new ResponseEntity<Object>(erroMap, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}
	
	/**
	 * 
	 * @param city
	 * @return
	 * 
	 *  This API used to filter  the atms by city
	 */

	@GetMapping(value = "/atms/{city}")
	public ResponseEntity<Object> getATMListByCity(@PathVariable("city") String city) {
		try {
			  String formatCity=city.replaceAll(" ", "%20"); // This code resolves the URL encode for path variable ex:city=Koog aan de Zaan
			List<ATMS> allatmList = delegateManager.getATMListByCity(city);
			HttpHeaders headers = responseUtils.getHeaders();
			if(allatmList!=null && allatmList.isEmpty()){
				ATMErrorResponse errorResp=responseUtils.getNoConfigurationResponse();
				return new ResponseEntity<Object>(errorResp, headers, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<Object>(allatmList, headers, HttpStatus.OK);
		} catch (Exception e) {
			ATMErrorResponse errorResp = responseUtils.getServcieDownErrorResponse();
			HttpHeaders headers = responseUtils.getHeaders();
			Map<String, ATMErrorResponse> erroMap = new HashMap();
			erroMap.put("errorMap", errorResp);
			return new ResponseEntity<Object>(erroMap, headers, HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

}
