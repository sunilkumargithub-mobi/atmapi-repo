package com.mobiquity.atmapi.constant;

public interface ATMConstant {
    public String RESP_CODE_400="400";
    public String RESP_DESCRIPTION_400="VALICATION_ERROR";
    public String RESP_CODE_500="500";
    public String RESP_DESCRIPTION_500="Service_Down/Network_Issue";
    public String RESP_DESCRIPTION_CITY="No atm's available for this City";
}
