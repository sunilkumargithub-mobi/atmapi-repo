package com.mobiquity.atmapi.utils;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.mobiquity.atmapi.exceptions.ApplicationException;
import com.mobiquity.atmapi.vo.ATMS;
import com.mobiquity.atmapi.vo.Address;
import com.mobiquity.atmapi.vo.OpeningHours;

/**
 * 
 * @author SunilKumar
 * 
 *         This class used to convert json string to java object
 *
 */

@Component
public class JsonUtils {

	/**
	 * 
	 * @param jsonString
	 * @param city
	 * @return
	 * 
	 * 		This method used to convert formatted json string to java objects
	 *         and get list of ATM's based on city
	 */

	public static List<ATMS> jsonConversionObject(String jsonString, String city) {
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		try {
			JSONArray array = new JSONArray(jsonString);
			List<ATMS> atmsList = new LinkedList();
			for (int i = 0; i < array.length(); i++) {
				ATMS atms = new ATMS();
				JSONObject object = array.getJSONObject(i);

				JSONObject jsonAddrObject = (JSONObject) object.get("address");
				Address address = new Address();
				if (jsonAddrObject.getString("city").equalsIgnoreCase(city.trim())) {
					address.setStreet(jsonAddrObject.getString("street"));
					address.setHousenumber(jsonAddrObject.getString("housenumber"));
					address.setPostalcode(jsonAddrObject.getString("postalcode"));
					address.setCity(jsonAddrObject.getString("city"));
					JSONObject jsonGeoLocObj = (JSONObject) jsonAddrObject.get("geoLocation");
					Address.Geolocation geolocation = new Address.Geolocation(jsonGeoLocObj.getString("lat"),
							jsonGeoLocObj.getString("lng"));
					address.setGeolocation(geolocation);
					Integer distance = object.getInt("distance");

					JSONArray jsonOpeningHrsArray = (JSONArray) object.get("openingHours");

					OpeningHours[] openingHoursArray = new OpeningHours[jsonOpeningHrsArray.length()];
					for (int j = 0; j < jsonOpeningHrsArray.length(); j++) {
						JSONObject openHrsObject = jsonOpeningHrsArray.getJSONObject(j);
						OpeningHours openingHours = new OpeningHours();
						openingHours.setDayOfWeek(openHrsObject.getInt("dayOfWeek"));

						JSONArray hoursArray = (JSONArray) openHrsObject.get("hours");
						for (int k = 0; k < hoursArray.length(); k++) {
							JSONObject hoursObject = hoursArray.getJSONObject(k);
							List hoursList = new LinkedList();
							OpeningHours.Hours hrs = new OpeningHours.Hours(hoursObject.getString("hourFrom"),
									hoursObject.getString("hourTo"));
							hoursList.add(hrs);
							openingHours.setHours(hoursList);
						}

						openingHoursArray[j] = openingHours;

					}

					atms.setAddress(address);
					atms.setDistance(distance);
					atms.setFunctionality(object.getString("functionality"));
					atms.setOpeningHours(openingHoursArray);
					atms.setType(object.getString("type"));
					atmsList.add(atms);
				}
			}
			return atmsList;
		} catch (JSONException e) {
			throw new ApplicationException();
		}

	}

	/**
	 * 
	 * @param jsonString
	 * @return
	 * 
	 * 		This method used to convert json string to proper formatted
	 *         conversion json string
	 */

	public String formattedJsonString(String jsonString) {
		String formattedString = jsonString.trim().substring(5, jsonString.length());
		return formattedString;
	}

}
