package com.mobiquity.atmapi.controller;

public class ATMServcieControllerTest {

}
